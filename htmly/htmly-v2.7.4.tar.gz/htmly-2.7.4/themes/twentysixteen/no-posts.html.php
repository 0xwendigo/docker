<article class="page type-page hentry">
    <header class="entry-header">
        <h1 class="entry-title">No posts found!</h1>    
    </header><!-- .entry-header -->
</article><!-- #post-## -->