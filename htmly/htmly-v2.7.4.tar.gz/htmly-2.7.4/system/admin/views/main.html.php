<?php
echo '<h2>Your recent posts</h2>';
get_user_posts();
echo '<h2>Static pages</h2>';
get_user_pages(); ?>